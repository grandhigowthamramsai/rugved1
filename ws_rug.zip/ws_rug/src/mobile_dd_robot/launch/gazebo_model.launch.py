from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource

from launch_ros.actions import Node
import os
import xacro

from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, Command

def generate_launch_description():
    robotXacroName = 'mobile_robot'
    namePackage = 'mobile_dd_robot'

    model_relative_path = 'model/robot.xacro'
    world_relative_path = "model/empty_world.world"

    Model_path = os.path.join(get_package_share_directory(namePackage), model_relative_path)
    pathWorld = os.path.join(get_package_share_directory(namePackage), world_relative_path)

    # Process the xacro file at runtime
    robotDescription = Command(['xacro ', Model_path])

    gazebo_rosPackageLaunch = PythonLaunchDescriptionSource(
        os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
    )
    gazeboLaunch = IncludeLaunchDescription(
        gazebo_rosPackageLaunch, launch_arguments={'world': pathWorld}.items()
    )

    spawnModelNode = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', robotXacroName],
        output='screen'
    )

    nodeRobotStatePublisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output="screen",
        parameters=[{'robot_description': robotDescription, 'use_sim_time': True}]
    )
    
    # Joint State Publisher (for visualization in RViz)
    nodeJointStatePublisher = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen'
    )

    # Launch RViz2
    nodeRViz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen'
    )

    LaunchDescriptionObject = LaunchDescription()
    LaunchDescriptionObject.add_action(gazeboLaunch)
    LaunchDescriptionObject.add_action(spawnModelNode)
    LaunchDescriptionObject.add_action(nodeRobotStatePublisher)
    LaunchDescriptionObject.add_action(nodeJointStatePublisher)
    LaunchDescriptionObject.add_action(nodeRViz)

    return LaunchDescriptionObject
